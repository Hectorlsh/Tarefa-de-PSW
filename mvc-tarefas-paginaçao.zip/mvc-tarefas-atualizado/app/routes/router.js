const tarefasController = require("../controllers/tarefasController");

// As rotas agora são definidas e exportadas diretamente pelo tarefasController
module.exports = tarefasController;
